<html>
	<head>
		<?php
			//parameters

			$product='';
			$quantity=0;
			$wlocation='ST009';
			//echo 'test';
			if (isset($_GET["product"])) $product=$_GET["product"];
			if (isset($_GET["quantity"])) $quantity=$_GET["quantity"];
			if (isset($_GET["wlocation"])) $wlocation=$_GET["wlocation"];
			
			//echo '<meta http-equiv="refresh" content="1;url=refresh.html"/>';
			echo '<meta http-equiv="refresh" content="0;url=list.php" />';
		?>
	</head>
	<body>
<!--
	<?php


			// database
			$host		=	'localhost';
			$user		=	'root';
			$pass		=	'sageerpX3';
			$database	=	'iotservices';

			// connect to the mysql database server.
			$connect = @mysql_connect ($host, $user, $pass);
			mysql_select_db($database, $connect) or die('Error: '.mysql_error());

			if ($quantity==0 or$wlocation==""){
				//echo 'test2';
			}
			else if ( $connect)
			{
				//echo 'connect';
				//generate auth_key
				//echo 'INSERT INTO `auth`(`prekey`, `authkey`, `date`, `email`) VALUES ("'.$prekey.'","'.$authkey.'",'.date("Y-m-d").',"'.$email.'")';
				//echo "<br>";
				// create the database.
				if ( ! @mysql_query ( 'INSERT INTO `stockcount`(`product`, `quantity`, `wlocation`) VALUES ("'.$product.'",'.$quantity.',"'.$wlocation.'")' ) )

				{
					die ( mysql_error() );
					echo 'sql error';
				}
				else {

					//send notification
					if ($product == "") {
						$ch =curl_init();
						curl_setopt($ch,CURLOPT_URL,"https://maker.ifttt.com/trigger/undobject/with/key/secretkey);
						curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
						$result=curl_exec($ch);
						curl_close($ch);
					}
					//echo $authkey;
					//$to      = $email;
					//$subject = 'Acuity API Authorization Key';
					//$message = 'Your auth key:'+$authkey;
					//$headers = 'From: spaulino@acutysolutions.co.uk' . "\r\n" .
					//	'Reply-To: spaulino@acutysolutions.co.uk' . "\r\n" .
					//	'X-Mailer: PHP/' . phpversion();

					//mail($to, $subject, $message, $headers);
					
				}
			}
			else {
				trigger_error ( mysql_error(), E_USER_ERROR );
			}
			//echo 'testttt';
		?>
-->
	</body>
</html>
