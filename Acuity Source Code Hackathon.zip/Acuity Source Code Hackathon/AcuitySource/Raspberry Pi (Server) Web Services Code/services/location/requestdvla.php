<html>
	<head>
		<?php
			//parameters

			$driver=0;
			$vehiclereg=0;
			$trailerid=0;
			$seats=0;
			$seatsbelts=0;
			$mirrors=0;
			$cabdoors=0;
			$plates=0;
			$suspension=0;
			$route=0;
			if (isset($_GET["driver"])) $driver=$_GET["driver"];
			if (isset($_GET["vehiclereg"])) $vehiclereg=$_GET["vehiclereg"];
			if (isset($_GET["trailerid"])) $trailerid=$_GET["trailerid"];
			if (isset($_GET["seats"])) $seats=$_GET["seats"];
			if (isset($_GET["seatsbelts"])) $seatsbelts=$_GET["seatsbelts"];
			if (isset($_GET["mirrors"])) $mirrors=$_GET["mirrors"];
			if (isset($_GET["cabdoors"])) $cabdoors=$_GET["cabdoors"];
			if (isset($_GET["plates"])) $plates=$_GET["plates"];
			if (isset($_GET["suspension"])) $suspension=$_GET["suspension"];
			if (isset($_GET["route"])) $route=$_GET["route"];
			
			//echo '<meta http-equiv="refresh" content="1;url=refresh.html"/>';
			echo '<meta http-equiv="refresh" content="1;url=refresh.html?route='.$route.'&vehicle='.$vehiclereg.'&trailer='.$trailerid.'" />';
		?>
	</head>
	<body>
<!--
		<?php


			// database
			$host		=	'localhost';
			$user		=	'root';
			$pass		=	'sageerpX3';
			$database	=	'iotservices';

			// connect to the mysql database server.
			$connect = @mysql_connect ($host, $user, $pass);
			mysql_select_db($database, $connect) or die('Error: '.mysql_error());

			if (1==2){
				
			}
			else if ( $connect)
			{
				//generate auth_key
				//echo 'INSERT INTO `auth`(`prekey`, `authkey`, `date`, `email`) VALUES ("'.$prekey.'","'.$authkey.'",'.date("Y-m-d").',"'.$email.'")';
				//echo "<br>";
				// create the database.
				if ( ! @mysql_query ( 'INSERT INTO `dvlaform`(`driver`, `vehiclereg`, `trailerid`, `seats`, `seatsbelts`, `mirrors`, `cabdoors`, `plates`, `suspension`) VALUES ('.$driver.','.$vehiclereg.','.$trailerid.','.$seats.','.$seatsbelts.','.$mirrors.','.$cabdoors.','.$plates.','.$suspension.')' ) )

				{
					die ( mysql_error() );
				}
				else {
					//send notification
					$ch =curl_init();
					curl_setopt($ch,CURLOPT_URL,"https://maker.ifttt.com/trigger/dvla/with/key/secretkey");
					curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
					$result=curl_exec($ch);
					curl_close($ch);

					
				}
			}
			else {
				trigger_error ( mysql_error(), E_USER_ERROR );
			}
		?>
-->
	</body>
</html>
