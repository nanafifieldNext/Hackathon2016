<html>
	<head>
		<?php
			//parameters

			$lon='';
			$lat='';
			$route='';
			$vehicle='';
			$trailer='';
			if (isset($_GET["lon"])) $lon=$_GET["lon"];
			if (isset($_GET["lat"])) $lat=$_GET["lat"];
			if (isset($_GET["route"])) $route=$_GET["route"];
			if (isset($_GET["vehicle"])) $vehicle=$_GET["vehicle"];
			if (isset($_GET["trailer"])) $trailer=$_GET["trailer"];
			//echo '<meta http-equiv="refresh" content="1;url=refresh.html"/>';
			echo '<meta http-equiv="refresh" content="1;url=refresh.html?route='.$route.'&vehicle='.$vehicle.'&trailer='.$trailer.'" />';
		?>
	</head>
	<body>
<!--
		<?php


			// database
			$host		=	'localhost';
			$user		=	'root';
			$pass		=	'sageerpX3';
			$database	=	'iotservices';

			// connect to the mysql database server.
			$connect = @mysql_connect ($host, $user, $pass);
			mysql_select_db($database, $connect) or die('Error: '.mysql_error());

			if ($lat=="" or $lon=="" or$route==""){
				
			}
			else if ( $connect)
			{
				//generate auth_key
				//echo 'INSERT INTO `auth`(`prekey`, `authkey`, `date`, `email`) VALUES ("'.$prekey.'","'.$authkey.'",'.date("Y-m-d").',"'.$email.'")';
				//echo "<br>";
				// create the database.
				if ( ! @mysql_query ( 'INSERT INTO `location`(`route`, `lat`, `lon`, `vehicle`, `trailer`) VALUES ("'.$route.'","'.$lat.'","'.$lon.'","'.$vehicle.'","'.$trailer.'")' ) )

				{
					die ( mysql_error() );
				}
				else {
					
					echo $authkey;
					$to      = $email;
					$subject = 'Acuity API Authorization Key';
					$message = 'Your auth key:'+$authkey;
					$headers = 'From: spaulino@acutysolutions.co.uk' . "\r\n" .
						'Reply-To: spaulino@acutysolutions.co.uk' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();

					mail($to, $subject, $message, $headers);
					
				}
			}
			else {
				trigger_error ( mysql_error(), E_USER_ERROR );
			}
		?>
-->
	</body>
</html>
