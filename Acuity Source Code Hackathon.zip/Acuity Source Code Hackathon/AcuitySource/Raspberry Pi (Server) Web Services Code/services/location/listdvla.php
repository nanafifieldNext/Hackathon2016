<?php

// database
$host		=	'localhost';
$user		=	'root';
$pass		=	'sageerpX3';
$database	=	'iotservices';

// connect to the mysql database server.
$connect = @mysql_connect ($host, $user, $pass);
mysql_select_db($database, $connect) or die('Error: '.mysql_error());

$sql = "SELECT * FROM dvlaform";
$result = mysql_query($sql);
				
if (mysql_num_rows($result) > 0) {
	// output data of each row
	$rows = array(); 
	while($r = mysql_fetch_assoc($result)) {
		$rows[] = $r; 
	} 
	print json_encode($rows);
				
} else {
	$rows = array(); 
	print json_encode($rows);
}

?>
